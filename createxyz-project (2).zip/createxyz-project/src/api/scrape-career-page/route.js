async function handler({ url }) {
  if (!url) {
    return {
      success: false,
      error: "No URL provided",
      jobs: [],
      careerPageUrl: null,
    };
  }

  try {
    // Normalize the URL to ensure it has http/https
    let baseUrl = url;
    if (!baseUrl.startsWith("http")) {
      baseUrl = "https://" + baseUrl;
    }

    // Extract the base domain
    const urlObj = new URL(baseUrl);
    const baseDomain = `${urlObj.protocol}//${urlObj.hostname}`;

    // First try the main website to find career links
    let mainPageResponse;
    try {
      mainPageResponse = await fetch("/integrations/web-scraping/post", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          url: baseUrl,
          getText: false, // Get HTML to find links
        }),
      });

      if (!mainPageResponse.ok) {
        console.log(
          "Failed to access main website:",
          baseUrl,
          mainPageResponse.status
        );
        return {
          success: false,
          error: `Website returned status code: ${mainPageResponse.status}`,
          jobs: [],
          careerPageUrl: null,
        };
      }
    } catch (error) {
      console.log("Error accessing main website:", error);
      return {
        success: false,
        error: `Could not access website: ${error.message}`,
        jobs: [],
        careerPageUrl: null,
      };
    }

    let mainPageHtml;
    try {
      mainPageHtml = await mainPageResponse.text();
    } catch (error) {
      console.log("Error parsing main page response:", error);
      return {
        success: false,
        error: "Failed to parse website content",
        jobs: [],
        careerPageUrl: null,
      };
    }

    // Look for career page links
    const careerLinkRegex =
      /<a[^>]*href=["']([^"']*(?:career|job|employ|opportunit|vacanc|join)[^"']*)["'][^>]*>(.*?)<\/a>/gi;
    let careerPageUrl = null;
    let match;

    while ((match = careerLinkRegex.exec(mainPageHtml)) !== null) {
      let href = match[1];

      // Handle relative URLs
      if (href.startsWith("/")) {
        careerPageUrl = `${baseDomain}${href}`;
      } else if (!href.startsWith("http")) {
        careerPageUrl = new URL(href, baseUrl).toString();
      } else {
        careerPageUrl = href;
      }
      break;
    }

    // If no career page found, try common career page URLs
    if (!careerPageUrl) {
      const commonCareerPaths = [
        "/careers",
        "/jobs",
        "/career",
        "/job",
        "/work-with-us",
        "/join-us",
        "/employment",
        "/about/careers",
        "/company/careers",
        "/about/jobs",
        "/opportunities",
        "/job-opportunities",
        "/join-our-team",
        "/vacancies",
      ];

      for (const path of commonCareerPaths) {
        try {
          const testUrl = new URL(path, baseUrl).toString();
          console.log("Trying potential career page:", testUrl);

          const response = await fetch("/integrations/web-scraping/post", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              url: testUrl,
              getText: true,
            }),
          });

          if (response.ok) {
            const text = await response.text();
            // Check if this page likely contains job listings
            if (text && text.match(/job|position|opening|vacancy|career/i)) {
              careerPageUrl = testUrl;
              console.log("Found career page at:", testUrl);
              break;
            }
          }
        } catch (e) {
          console.log("Error checking path:", path, e);
          // Continue trying other paths
          continue;
        }
      }
    }

    let careerPageText = null;
    let jobEmail = null;

    // If we found a career page, scrape it for job listings
    if (careerPageUrl) {
      console.log("Scraping career page:", careerPageUrl);
      let careerPageResponse;

      try {
        careerPageResponse = await fetch("/integrations/web-scraping/post", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            url: careerPageUrl,
            getText: true,
          }),
        });

        if (!careerPageResponse.ok) {
          console.log(
            "Failed to access career page:",
            careerPageUrl,
            careerPageResponse.status
          );
          return {
            success: false,
            error: "Failed to access career page",
            jobs: [],
            careerPageUrl,
          };
        }
      } catch (error) {
        console.log("Error accessing career page:", error);
        return {
          success: false,
          error: "Failed to access career page: " + error.message,
          jobs: [],
          careerPageUrl,
        };
      }

      try {
        careerPageText = await careerPageResponse.text();
      } catch (error) {
        console.log("Error parsing career page response:", error);
        return {
          success: false,
          error: "Failed to parse career page content",
          jobs: [],
          careerPageUrl,
        };
      }
    } else {
      // If no dedicated career page found, use the main page content
      careerPageText = mainPageHtml;
      careerPageUrl = baseUrl;

      // Try to find job-related email in contact pages
      const contactPaths = ["/contact", "/contact-us", "/about-us"];

      for (const path of contactPaths) {
        try {
          const contactUrl = new URL(path, baseUrl).toString();

          const response = await fetch("/integrations/web-scraping/post", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              url: contactUrl,
              getText: false,
            }),
          });

          if (response.ok) {
            const html = await response.text();
            const emailRegex =
              /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9._-]+)/gi;
            const emails = html.match(emailRegex) || [];

            // Look for job-related emails
            for (const email of emails) {
              if (
                email.includes("job") ||
                email.includes("career") ||
                email.includes("hr") ||
                email.includes("recruit")
              ) {
                jobEmail = email;
                break;
              }
            }

            if (jobEmail) break;
          }
        } catch (error) {
          console.log(`Error checking ${path} for contact info:`, error);
        }
      }
    }

    // If we still don't have content, return an error
    if (!careerPageText) {
      return {
        success: false,
        error: "Could not retrieve website content",
        jobs: [],
        careerPageUrl: null,
        jobEmail,
      };
    }

    // Extract potential job titles using improved patterns
    const jobTitlePatterns = [
      /job title[s]?:?\s*(.*?)(?:<|$)/gi,
      /position[s]?:?\s*(.*?)(?:<|$)/gi,
      /vacancy:?\s*(.*?)(?:<|$)/gi,
      /opening[s]?:?\s*(.*?)(?:<|$)/gi,
      /<h\d[^>]*>(.*?(?:engineer|manager|director|specialist|analyst|designer|developer|assistant|coordinator|representative|technician|administrator|officer|consultant).*?)<\/h\d>/gi,
      /<li[^>]*>(.*?(?:engineer|manager|director|specialist|analyst|designer|developer|assistant|coordinator|representative|technician|administrator|officer|consultant).*?)<\/li>/gi,
      /<div[^>]*class=["'].*?job.*?["'][^>]*>(.*?)<\/div>/gi,
      /<div[^>]*class=["'].*?position.*?["'][^>]*>(.*?)<\/div>/gi,
      /<div[^>]*class=["'].*?career.*?["'][^>]*>(.*?)<\/div>/gi,
      /<div[^>]*class=["'].*?vacancy.*?["'][^>]*>(.*?)<\/div>/gi,
      /<a[^>]*href=["'].*?(?:job|career|position).*?["'][^>]*>(.*?)<\/a>/gi,
      /<span[^>]*class=["'].*?job.*?["'][^>]*>(.*?)<\/span>/gi,
      /<p[^>]*>(.*?(?:we are looking for|we are hiring|join our team|apply for)[^<]*)<\/p>/gi,
    ];

    let jobTitles = [];

    for (const pattern of jobTitlePatterns) {
      let match;
      while ((match = pattern.exec(careerPageText)) !== null) {
        // Clean up the job title
        const jobTitle = match[1]
          .replace(/<[^>]*>/g, "") // Remove HTML tags
          .replace(/&nbsp;/g, " ") // Replace &nbsp; with spaces
          .replace(/\s+/g, " ") // Replace multiple spaces with single space
          .trim();

        if (jobTitle && jobTitle.length > 3 && jobTitle.length < 100) {
          jobTitles.push(jobTitle);
        }
      }
    }

    // Remove duplicates and limit to 10 jobs
    jobTitles = [...new Set(jobTitles)].slice(0, 10);

    console.log("Found job titles:", jobTitles);

    // If we found a job email but no job listings
    if (jobTitles.length === 0 && jobEmail) {
      return {
        success: true,
        jobs: [],
        careerPageUrl,
        jobEmail,
        message:
          "Couldn't find specific job listings, but found an email for job inquiries.",
      };
    }

    return {
      success:
        jobTitles.length > 0 || (careerPageUrl && careerPageUrl !== baseUrl),
      jobs: jobTitles,
      careerPageUrl,
      jobEmail,
      error:
        jobTitles.length === 0 && !jobEmail ? "No job listings found" : null,
      message:
        jobTitles.length === 0 && careerPageUrl !== baseUrl
          ? "Found a potential career page but couldn't extract specific job listings."
          : null,
    };
  } catch (error) {
    console.error("Error scraping career page:", error);
    return {
      success: false,
      error: "Failed to scrape career page: " + error.message,
      jobs: [],
      careerPageUrl: null,
    };
  }
}