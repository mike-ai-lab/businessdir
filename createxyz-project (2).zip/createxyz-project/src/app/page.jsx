"use client";
import React from "react";

function MainComponent() {
  const [location, setLocation] = useState("");
  const [category, setCategory] = useState("");
  const [locationSuggestions, setLocationSuggestions] = useState([]);
  const [businesses, setBusinesses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [jobListings, setJobListings] = useState({});
  const [loadingJobs, setLoadingJobs] = useState({});

  const categories = [
    "Architecture",
    "Medical",
    "Marketing",
    "Legal",
    "Technology",
    "Food & Beverage",
    "Retail",
    "Construction",
    "Education",
    "Finance",
  ];

  const fetchLocationSuggestions = async (input) => {
    if (!input || input.length < 2) {
      setLocationSuggestions([]);
      return;
    }

    try {
      const response = await fetch(
        `/integrations/google-place-autocomplete/autocomplete/json?input=${encodeURIComponent(
          input
        )}&radius=500`
      );

      if (!response.ok) {
        throw new Error(
          `Error fetching location suggestions: ${response.status}`
        );
      }

      const data = await response.json();
      setLocationSuggestions(data.predictions || []);
    } catch (err) {
      console.error("Failed to fetch location suggestions:", err);
      setError("Failed to fetch location suggestions. Please try again.");
      setLocationSuggestions([]);
    }
  };

  const handleLocationChange = (e) => {
    const value = e.target.value;
    setLocation(value);
    fetchLocationSuggestions(value);
    setShowSuggestions(true);
  };

  const handleSelectLocation = (suggestion) => {
    setLocation(suggestion.description);
    setLocationSuggestions([]);
    setShowSuggestions(false);
  };

  const handleSearch = async () => {
    if (!location) {
      setError("Please enter a location");
      return;
    }

    setLoading(true);
    setError(null);
    setBusinesses([]);

    try {
      let query = `${category} in ${location}`;

      const response = await fetch(
        `/integrations/local-business-data/search?query=${encodeURIComponent(
          query
        )}&limit=20`
      );

      if (!response.ok) {
        throw new Error(`Error fetching businesses: ${response.status}`);
      }

      const data = await response.json();

      if (data.status === "OK" && data.data && data.data.length > 0) {
        setBusinesses(data.data);
      } else {
        setBusinesses([]);
      }
    } catch (err) {
      console.error("Failed to fetch businesses:", err);
      setError("Failed to fetch businesses. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const fetchJobListings = async (businessId, website) => {
    if (!website || loadingJobs[businessId]) return;

    setLoadingJobs((prev) => ({ ...prev, [businessId]: true }));

    try {
      let websiteUrl = website;
      if (
        !websiteUrl.startsWith("http://") &&
        !websiteUrl.startsWith("https://")
      ) {
        websiteUrl = "https://" + websiteUrl;
      }

      const response = await fetch("/api/scrape-career-page", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ url: websiteUrl }),
      });

      if (!response.ok) {
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();

      setJobListings((prev) => ({
        ...prev,
        [businessId]: {
          jobs: data.jobs || [],
          careerPageUrl: data.careerPageUrl,
          jobEmail: data.jobEmail,
          success: data.success,
          message: data.message,
          error: data.error,
        },
      }));
    } catch (error) {
      console.error("Error fetching job listings:", error);
      setJobListings((prev) => ({
        ...prev,
        [businessId]: {
          jobs: [],
          success: false,
          error: error.message || "Failed to fetch job listings",
        },
      }));
    } finally {
      setLoadingJobs((prev) => ({ ...prev, [businessId]: false }));
    }
  };

  const renderStars = (rating) => {
    if (!rating) return null;

    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);

    return (
      <div className="flex items-center">
        {[...Array(fullStars)].map((_, i) => (
          <i key={`full-${i}`} className="fas fa-star text-[#000000]"></i>
        ))}
        {halfStar && <i className="fas fa-star-half-alt text-[#000000]"></i>}
        {[...Array(emptyStars)].map((_, i) => (
          <i key={`empty-${i}`} className="far fa-star text-[#000000]"></i>
        ))}
      </div>
    );
  };

  const getBusinessStatus = (business) => {
    if (!business.business_status) return null;

    if (business.business_status === "OPEN") {
      return <span className="text-[#000000] font-lato">Open</span>;
    } else if (business.business_status === "CLOSED_TEMPORARILY") {
      return (
        <span className="text-[#000000] font-lato">Temporarily Closed</span>
      );
    } else if (business.business_status === "CLOSED") {
      return <span className="text-[#000000] font-lato">Closed</span>;
    }

    return null;
  };

  const descriptiveTerms = [
    { term: "Predictable", explanation: "Success" },
    { term: "Up-to-date", explanation: "Design" },
    { term: "Qualitative", explanation: "Layout" },
    { term: "Impressive", explanation: "Result" },
    { term: "In time", explanation: "No exceptions" },
    { term: "Responsive", explanation: "Service" },
  ];

  return (
    <div className="min-h-screen bg-white font-lato">
      <header className="bg-[#000000] text-white py-16">
        <div className="container mx-auto px-4">
          <div className="mb-12">
            <h1 className="text-6xl md:text-8xl font-bold mb-6 font-pt-serif tracking-tight">
              <span className="block">we are</span>
              <span className="block">Business Directory</span>
            </h1>
            <p className="text-xl font-lato">
              Find local businesses and job opportunities
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mt-12">
            {descriptiveTerms.map((item, index) => (
              <div key={index} className="mb-4">
                <h3 className="text-xl font-semibold font-lato">{item.term}</h3>
                <p className="text-sm text-gray-300 font-lato">
                  ({item.explanation})
                </p>
              </div>
            ))}
          </div>
        </div>
      </header>

      <section className="container mx-auto px-4 py-16">
        <div className="border border-[#000000] p-8 mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="relative">
              <label
                htmlFor="location"
                className="block text-[#000000] mb-3 font-medium font-lato"
              >
                Location
              </label>
              <input
                type="text"
                id="location"
                className="w-full px-4 py-3 border-b border-[#000000] focus:outline-none focus:border-[#000000] bg-transparent font-lato"
                placeholder="Enter city, state, or zip code"
                value={location}
                onChange={handleLocationChange}
                onFocus={() => setShowSuggestions(true)}
              />
              {showSuggestions && locationSuggestions.length > 0 && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-[#000000] max-h-60 overflow-y-auto">
                  {locationSuggestions.map((suggestion) => (
                    <div
                      key={suggestion.place_id}
                      className="px-4 py-3 hover:bg-gray-100 cursor-pointer font-lato"
                      onClick={() => handleSelectLocation(suggestion)}
                    >
                      {suggestion.description}
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label
                htmlFor="category"
                className="block text-[#000000] mb-3 font-medium font-lato"
              >
                Category
              </label>
              <select
                id="category"
                className="w-full px-4 py-3 border-b border-[#000000] focus:outline-none focus:border-[#000000] bg-transparent font-lato appearance-none"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                <option value="">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-end">
              <button
                className="w-full bg-[#000000] text-white py-3 px-6 hover:bg-[#333333] transition duration-300 focus:outline-none font-lato"
                onClick={handleSearch}
                disabled={loading}
              >
                {loading ? (
                  <span className="flex items-center justify-center">
                    <i className="fas fa-spinner fa-spin mr-2"></i> Searching...
                  </span>
                ) : (
                  <span>Search</span>
                )}
              </button>
            </div>
          </div>

          {error && (
            <div className="mt-6 text-[#000000] border border-[#000000] p-4">
              <i className="fas fa-exclamation-circle mr-2"></i> {error}
            </div>
          )}
        </div>

        <div>
          {businesses.length > 0 ? (
            <div>
              <h2 className="text-4xl font-bold mb-12 text-[#000000] font-pt-serif">
                Results ({businesses.length})
              </h2>
              <div className="grid grid-cols-1 gap-12">
                {businesses.map((business) => (
                  <FramerMotion
                    key={business.business_id}
                    className="border border-[#000000] p-8 hover:border-[#333333] transition-all duration-300"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                  >
                    <div className="flex flex-col md:flex-row justify-between items-start gap-6">
                      <div className="flex-1">
                        <h3 className="text-2xl font-bold text-[#000000] mb-4 font-pt-serif">
                          {business.name}
                        </h3>
                        <div className="flex items-center mb-6">
                          {renderStars(business.rating)}
                          {business.rating && (
                            <span className="ml-3 text-[#000000] font-lato">
                              {business.rating} (
                              {business.review_count ||
                                business.user_ratings_total ||
                                0}{" "}
                              reviews)
                            </span>
                          )}
                        </div>

                        <div className="mb-6 space-y-3">
                          {business.full_address ||
                          business.formatted_address ? (
                            <div className="flex items-start">
                              <i className="fas fa-map-marker-alt text-[#000000] mt-1 mr-3"></i>
                              <span className="font-lato text-[#000000]">
                                {business.full_address ||
                                  business.formatted_address}
                              </span>
                            </div>
                          ) : null}

                          {business.phone_number ||
                          business.formatted_phone_number ? (
                            <div className="flex items-center">
                              <i className="fas fa-phone text-[#000000] mr-3"></i>
                              <span className="font-lato text-[#000000]">
                                {business.phone_number ||
                                  business.formatted_phone_number}
                              </span>
                            </div>
                          ) : null}

                          {business.website && (
                            <div className="flex items-center">
                              <i className="fas fa-globe text-[#000000] mr-3"></i>
                              <a
                                href={business.website}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[#000000] hover:underline font-lato"
                              >
                                {business.website
                                  .replace(/^https?:\/\//, "")
                                  .replace(/\/$/, "")}
                              </a>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-col items-start">
                        <div className="mb-4">
                          {getBusinessStatus(business)}
                        </div>

                        {business.website && (
                          <button
                            className="border border-[#000000] text-[#000000] py-2 px-6 hover:bg-[#000000] hover:text-white transition duration-300 focus:outline-none font-lato"
                            onClick={() =>
                              fetchJobListings(
                                business.business_id,
                                business.website
                              )
                            }
                            disabled={loadingJobs[business.business_id]}
                          >
                            {loadingJobs[business.business_id] ? (
                              <span className="flex items-center">
                                <i className="fas fa-spinner fa-spin mr-2"></i>{" "}
                                Finding Jobs...
                              </span>
                            ) : jobListings[business.business_id] ? (
                              <span>Refresh Job Listings</span>
                            ) : (
                              <span>Find Job Openings</span>
                            )}
                          </button>
                        )}
                      </div>
                    </div>

                    {jobListings[business.business_id] && (
                      <div className="mt-8 pt-8 border-t border-[#000000]">
                        <h4 className="font-semibold text-[#000000] mb-4 font-pt-serif text-xl">
                          Job Openings:
                        </h4>
                        {loadingJobs[business.business_id] ? (
                          <div className="flex items-center text-[#000000] font-lato">
                            <i className="fas fa-spinner fa-spin mr-2"></i>{" "}
                            Loading job listings...
                          </div>
                        ) : jobListings[business.business_id].success &&
                          jobListings[business.business_id].jobs &&
                          jobListings[business.business_id].jobs.length > 0 ? (
                          <div>
                            <ul className="list-none text-[#000000] space-y-2">
                              {jobListings[business.business_id].jobs.map(
                                (job, index) => (
                                  <li key={index} className="font-lato">
                                    • {job}
                                  </li>
                                )
                              )}
                            </ul>
                            {jobListings[business.business_id]
                              .careerPageUrl && (
                              <a
                                href={
                                  jobListings[business.business_id]
                                    .careerPageUrl
                                }
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[#000000] hover:underline font-lato inline-block mt-4"
                              >
                                View all openings on their career page
                              </a>
                            )}
                          </div>
                        ) : (
                          <div className="text-[#000000] font-lato">
                            {jobListings[business.business_id].message ? (
                              <p>{jobListings[business.business_id].message}</p>
                            ) : (
                              <p>
                                {jobListings[business.business_id].error ||
                                  "No job listings found"}
                              </p>
                            )}

                            {jobListings[business.business_id]
                              .careerPageUrl && (
                              <a
                                href={
                                  jobListings[business.business_id]
                                    .careerPageUrl
                                }
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-[#000000] hover:underline inline-block mt-4"
                              >
                                Visit their career page
                              </a>
                            )}

                            {jobListings[business.business_id].jobEmail && (
                              <div className="mt-4">
                                <p className="font-lato">
                                  Contact for job inquiries:
                                </p>
                                <a
                                  href={`mailto:${
                                    jobListings[business.business_id].jobEmail
                                  }`}
                                  className="text-[#000000] hover:underline font-lato"
                                >
                                  {jobListings[business.business_id].jobEmail}
                                </a>
                              </div>
                            )}

                            {!jobListings[business.business_id].careerPageUrl &&
                              !jobListings[business.business_id].jobEmail &&
                              business.website && (
                                <a
                                  href={business.website}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-[#000000] hover:underline inline-block mt-4 font-lato"
                                >
                                  Check their website for job openings
                                </a>
                              )}
                          </div>
                        )}
                      </div>
                    )}
                  </FramerMotion>
                ))}
              </div>
            </div>
          ) : loading ? (
            <div className="text-center py-24">
              <i className="fas fa-spinner fa-spin text-5xl text-[#000000] mb-6"></i>
              <p className="text-2xl text-[#000000] font-pt-serif">
                Searching for businesses...
              </p>
            </div>
          ) : (
            <div className="text-center py-24 border border-[#000000]">
              <i className="fas fa-search text-5xl text-[#000000] mb-6"></i>
              <p className="text-2xl text-[#000000] font-pt-serif">
                Enter a location and category to find businesses
              </p>
            </div>
          )}
        </div>
      </section>

      <footer className="bg-[#000000] text-white py-12 mt-16">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-8 md:mb-0">
              <h2 className="text-3xl font-bold font-pt-serif mb-2">
                Business Directory
              </h2>
              <p className="text-gray-300 font-lato">
                Find local businesses and job opportunities
              </p>
            </div>
            <div>
              <p className="text-gray-300 font-lato">
                &copy; {new Date().getFullYear()} Business Directory. All rights
                reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;